#!/bin/bash
#Ramyond Ezekiel
#script Purpose

uname -a > OSstatus.txt
lsb_release -a >> OSstatus.txt
sudo apt-get install lm-sensors >> OSstatus.txt
sensors >> OSstatus.txt  
df >> OSstatus.txt  
