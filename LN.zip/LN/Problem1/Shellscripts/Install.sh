#!/bin/bash

#Raymond Ezekiel
#Navigating Linux

#Purpose of script

sudo apt-get update -y #fetch updates
sudo apt-get upgrade -y #upgrade but no distro upgrade

echo "install nmap and zenmap" > install_result.txt
echo >> install_result.txt
echo >> install_result.txt
sudo apt-get install -y nmap zenmap >> install_result.txt
echo >> install_result.txt

echo "install random tools" >> install_result.txt
echo >> install_result.txt                                                       echo >> install_result.txt 

sudo apt-get install -y r-base wireshark #randomly selected tools

echo "You are done" >> install_result.txt
